/* Questions transcribed from the two AP European History practice exam PDFs. For personal study only. */
window.TESTS = {
 "y2017": {
  "title": "AP European History Practice Exam (2017)",
  "short": "2017 Practice Exam",
  "sets": [
   {
    "passage": {
     "intro": "Questions 1–4 refer to the image below.",
     "items": [
      {
       "caption": "Giorgio Vasari, The Massacre of the Huguenots, painting commissioned by Pope Gregory XIII for the papal residence in the Vatican, 1574"
      },
      {
       "img": "images/y17-vasari-massacre.jpg",
       "alt": "Vasari, The Massacre of the Huguenots"
      },
      {
       "note": "Alinari / Art Resource, NY"
      },
      {
       "note": "Vasari’s painting depicts an episode of government-sanctioned mob violence against Protestants in France, sometimes called the Saint Bartholomew’s Day Massacre (1572).",
       "italic": true
      }
     ]
    },
    "questions": [
     {
      "stem": "Incidents such as the one depicted in Vasari’s painting contributed most directly to which of the following?",
      "choices": [
       "The exacerbation of conflicts between the Valois monarchy and various noble factions",
       "The establishment of royal absolutism under Louis XIII and Louis XIV",
       "The entry of France in the Thirty Years’ War on the side of the Protestants",
       "The intensification of the grievances of the Third Estate against the nobility and the clergy"
      ],
      "answer": "A"
     },
     {
      "stem": "Which of the following was most directly intended to resolve the conflict illustrated in Vasari’s painting?",
      "choices": [
       "The Peace of Augsburg",
       "The Edict of Nantes",
       "The Pragmatic Sanction",
       "The Civil Constitution of the Clergy"
      ],
      "answer": "B"
     },
     {
      "stem": "Based on the imagery and intended audience of Vasari’s painting, the artist’s most likely purpose was to portray the events in the painting as",
      "choices": [
       "a terrible misunderstanding",
       "a horrific abuse of royal power",
       "an example of divine retribution",
       "a cautionary tale against the dangers of mob violence"
      ],
      "answer": "C"
     },
     {
      "stem": "Vasari’s interpretation of the events depicted in the painting would most likely have been shared by which of the following groups in the sixteenth century?",
      "choices": [
       "High clergy in the Church of England",
       "The rebels in the German Peasants’ War",
       "The delegates at the Council of Trent",
       "Christian humanists such as Erasmus of Rotterdam"
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 5–7 refer to the passage below.",
     "items": [
      "“All the dregs of humanity produced in the provinces make up the population of this city, and in this lies its greatness: not in fine buildings, and not in great merchants and thinkers and men of letters, as make Paris, London, Lisbon, and Amsterdam great cities; but in those of the lowest behavior and dishonesty, who, by intermarrying increase and multiply so that each generation is worse than the one before.”",
      {
       "src": "Bernardo Tanucci, satirical description of his home city of Naples, Italy, Epistolario, 1742"
      }
     ]
    },
    "questions": [
     {
      "stem": "Which of the following can best be inferred from Tanucci’s sarcastic reference to Naples’ greatness?",
      "choices": [
       "Naples was facing unique social problems that other cities were not facing during this period.",
       "The mercantilist policies implemented by the city’s ruling class had failed to develop Naples’ economy.",
       "The spread of print materials in vernacular languages threatened Italy’s intellectual monopoly.",
       "Some southern European intellectuals felt that their societies were falling behind those of Atlantic Europe."
      ],
      "answer": "D"
     },
     {
      "stem": "Tanucci’s opinion of the people of Naples most clearly exemplifies which of the following?",
      "choices": [
       "Concern about the erosion of traditional values as a result of urbanization",
       "The belief that southern Italy was falling behind northern Italy economically",
       "Fears that Italy was reaching Malthusian population limits",
       "The Enlightenment belief in the perfectability of humanity"
      ],
      "answer": "A"
     },
     {
      "stem": "The growth of Naples’ population as described by Tanucci is most likely a result of which of the following?",
      "choices": [
       "The expansion of cottage industry and the putting-out system",
       "The development of new financial institutions",
       "The imposition of guild restrictions on labor",
       "The expansion of commercial agriculture"
      ],
      "answer": "D"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 8 and 9 refer to the image below.",
     "items": [
      {
       "caption": "Jan Steen, Dutch painter, Beware of Luxury, 1663"
      },
      {
       "img": "images/y17-steen-luxury.jpg",
       "alt": "Jan Steen, Beware of Luxury"
      },
      {
       "note": "Erich Lessing / Art Resource, NY"
      }
     ]
    },
    "questions": [
     {
      "stem": "The features of seventeenth-century Dutch life reflected in the painting were largely a result of which of the following?",
      "choices": [
       "Dutch territorial gains in the Thirty Years’ War",
       "Dutch financial innovation and overseas trade",
       "The accession of a member of the Dutch House of Orange to the throne of England",
       "The successful raids of Dutch privateers against Spanish treasure fleets"
      ],
      "answer": "B"
     },
     {
      "stem": "The painting reflects which of the following conflicts?",
      "choices": [
       "Urban wealth versus rural poverty",
       "Catholic extravagance versus Protestant austerity",
       "French sophistication versus Dutch simplicity",
       "Traditional morality versus new consumerism"
      ],
      "answer": "D"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 10–13 refer to the passage below.",
     "items": [
      "“I wrote this book in the [1930s], against the background of depression at home and mounting tension abroad. The preoccupations of that unhappy time cast their shadows over its pages. I wrote with the knowledge, sometimes intimate, sometimes more distant, of conditions in depressed and derelict areas, of the sufferings of the unwanted and uprooted—the two million unemployed at home, the Jewish and liberal fugitives from Germany. . . . Admittedly, the atmosphere of the [1930s] had something to do with my choice of subject as well as with my methods of treatment. Many of my generation who grew up under the shadow of the First World War had a sincere, if mistaken, conviction that all wars were unnecessary and useless. I no longer think that all wars are unnecessary; but some are, and I still think that the Thirty Years War was one of these. It need not have happened and it settled nothing worth settling.”",
      {
       "src": "Cicely Veronica Wedgwood, British historian, The Thirty Years War, originally published in 1938, excerpt from the revised introduction published as part of the 1956 reprint"
      }
     ]
    },
    "questions": [
     {
      "stem": "The author’s conclusion regarding the significance of the Thirty Years’ War most directly challenged which of the following historical interpretations?",
      "choices": [
       "The Thirty Years’ War was a uniquely devastating conflict in pre-twentieth-century European history.",
       "The Thirty Years’ War marked a decisive turning point in European history.",
       "Although ostensibly a conflict driven by religious differences, the Thirty Years’ War resulted from a variety of factors.",
       "The devastation of the Thirty Years’ War undermined the theological justification for the concept of just war."
      ],
      "answer": "B"
     },
     {
      "stem": "Based on the passage and the historical context in which Wedgwood’s book was originally published, which of the following most heavily influenced the author’s view of the Thirty Years’ War?",
      "choices": [
       "The emergence of second-wave feminism in Europe",
       "The spread of existentialist thought in Britain during the Great Depression",
       "Growing international tensions in Europe as a result of aggressive nationalism",
       "Increasing tensions between the United States and the Soviet Union during the Cold War"
      ],
      "answer": "C"
     },
     {
      "stem": "Which of the following best explains why, in the 1956 edition of the book, the author stated, “I no longer think that all wars are unnecessary”?",
      "choices": [
       "The Second World War opened up new economic and social opportunities for women.",
       "The Second World War led more writers to question literary conventions and bourgeois social values.",
       "The Second World War opened up Europe to increased American cultural and economic influence.",
       "The Second World War had to be fought to stop the expansion of Nazi Germany in Europe."
      ],
      "answer": "D"
     },
     {
      "stem": "Which of the following most directly undermines the author’s argument that the Thirty Years’ War “settled nothing worth settling”?",
      "choices": [
       "The Thirty Years War had a devastating impact on civilian populations in many parts of northern Europe.",
       "The ideal of a universal Christendom was effectively abandoned as religion largely ceased to be the major cause for warfare between European states.",
       "The rulers of the German states maintained the right to designate the official religion of their territories.",
       "Charles II was restored as the king of England after the interregnum of Oliver Cromwell’s Puritan military dictatorship."
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 14–16 are based on the passage below.",
     "items": [
      "“The 9th [of June, 1789]. The business going forward at present in the pamphlet shops of Paris is incredible. I went to the Palais Royal [where many pamphleteers’ shops were located] to see what new things were published and to procure a catalogue of all. Every hour produces something new. Thirteen came out today, sixteen yesterday, and ninety-two last week. . . .",
      "The spirit of reading political tracts, they say, spread into the provinces, so that all the presses of France are equally employed. Nineteen out of twenty of these productions are in favor of liberty, and commonly violent against the clergy and nobility; . . . but enquiring for such as had appeared on the other side of the question, to my astonishment I find that there are but two or three that have merit enough to be known. Is it not [surprising], that while the press teems with the most leveling and seditious principles, that if put in execution would overturn the monarchy, nothing in reply appears, and not the least step is taken by the court to restrain these publications?”",
      {
       "src": "Arthur Young, English writer, account of travels in France, published 1792"
      }
     ]
    },
    "questions": [
     {
      "stem": "Young’s account provides potential information about the origins of the French Revolution. A historian wishing to evaluate the usefulness of his account would likely be interested in all the following questions EXCEPT:",
      "choices": [
       "What was the typical amount of labor required to run a printing press?",
       "What was the typical number of copies printed per pamphlet?",
       "What was the literacy rate in France on the eve of the Revolution?",
       "What was the typical retail price of a pamphlet, relative to average wages?"
      ],
      "answer": "A"
     },
     {
      "stem": "Since 1699 all printed materials in France had been subject to the approval of royal censors. Young’s account most likely implies that",
      "choices": [
       "producers of pamphlets were reluctant to discuss the activities of censors, for fear of having their shops closed down",
       "coming from Britain, with its free press, Young was unfamiliar with the concept of state censorship of books",
       "by 1789 the system of royal censorship in France had largely ceased to function as originally intended",
       "because of the large number of titles involved, political pamphlets were not subject to the same laws and regulations regarding censorship as books"
      ],
      "answer": "C"
     },
     {
      "stem": "In addition to the political pamphlets described in the passage, which of the following did the most to turn public opinion against the Old Regime?",
      "choices": [
       "French physiocrats’ critique of mercantilism",
       "Adam Smith’s Wealth of Nations",
       "Discussions in French salons and coffeehouses",
       "The paintings of Jacques-Louis David"
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 17 and 18 refer to the painting below.",
     "items": [
      {
       "caption": "Isidore Pils, French painter, Rouget de Lisle Singing “La Marseillaise,” 1849"
      },
      {
       "img": "images/y17-pils-marseillaise.jpg",
       "alt": "Pils, Rouget de Lisle Singing La Marseillaise"
      },
      {
       "note": "Snark / Art Resource, NY"
      },
      {
       "note": "The painting portrays Claude-Joseph Rouget de Lisle, a composer, offering the first performance, in 1792, of his patriotic song “La Marseillaise,” which became the French national anthem.",
       "italic": true
      }
     ]
    },
    "questions": [
     {
      "stem": "The painting most strongly suggests a link between nationalism and which of the following?",
      "choices": [
       "Anarchism",
       "Conservatism",
       "Neoclassicism",
       "Romanticism"
      ],
      "answer": "D"
     },
     {
      "stem": "Pils’ choice of subject matter and his treatment of it were probably most strongly influenced by which of the following contemporary developments?",
      "choices": [
       "The publication of Marxist theory on the causes and course of future revolutions",
       "The outbreak of revolution in France in the previous year",
       "The ongoing economic crisis in Europe known as the “Hungry ’40s”",
       "The institution of a more representative form of government in Great Britain as a result of the Reform Bills"
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 19–21 refer to the maps below.",
     "items": [
      {
       "img": "images/y17-maps-cities.jpg",
       "alt": "Maps of European cities with more than 500,000 inhabitants, 1850 and 1910"
      }
     ]
    },
    "questions": [
     {
      "stem": "Which of the following contributed most to the overall trend represented on the maps?",
      "choices": [
       "The increased immigration to Europe from colonial territories",
       "The relative peacefulness of international relations within Europe",
       "The unification of major European ethnic groups into nation-states",
       "The development of industrialized economies"
      ],
      "answer": "D"
     },
     {
      "stem": "The trend represented on the maps led most European governments in the period to adopt policies to",
      "choices": [
       "subsidize agriculture in an attempt to limit migration to the cities",
       "place additional restrictions on the political rights of urban residents",
       "establish police forces and enact public health measures",
       "encourage emigration to overseas colonies to ease overcrowding within Europe"
      ],
      "answer": "C"
     },
     {
      "stem": "The disparity on the 1910 map between the eastern region of Europe and the western and central regions was primarily the result of which of the following?",
      "choices": [
       "Differences in the frequency and scale of military conflicts",
       "Differences in the degree of political centralization",
       "Differences in the numbers of emigrants",
       "Differences in landholding patterns and agricultural practices"
      ],
      "answer": "D"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 22–24 refer to the song below.",
     "items": [
      {
       "poem": [
        "“Father Stalin, look at this",
        "Collective farming is just bliss",
        "The hut’s in ruins, the barn’s all sagged",
        "All the horses broken nags",
        "And on the hut a hammer and sickle",
        "And in the hut death and famine",
        "No cows left, no pigs at all",
        "Just your picture on the wall",
        "Daddy and mommy are in the kolkhoz*",
        "The poor child cries as alone he goes",
        "There’s no bread and there’s no fat",
        "The Party’s ended all of that",
        "The Party man he beats and stamps",
        "And sends us to Siberian camps.”"
       ]
      },
      {
       "note": "*collective farm"
      },
      {
       "src": "Ukrainian underground protest song, 1930s"
      }
     ]
    },
    "questions": [
     {
      "stem": "The famine described in the song was a consequence of which of the following?",
      "choices": [
       "The civil war between the Bolsheviks and their opponents",
       "The drive to modernize the Soviet economy",
       "The implementation of the New Economic Policy",
       "The onset of the Great Depression"
      ],
      "answer": "B"
     },
     {
      "stem": "The Soviet government’s agricultural policies referred to in the song directly resulted in which of the following?",
      "choices": [
       "The embrace of free-market reforms",
       "The campaign to liquidate the kulaks",
       "The rise of authoritarian dictatorships in eastern Europe and Spain in the 1930s",
       "The strengthening of right-wing parties in western Europe"
      ],
      "answer": "B"
     },
     {
      "stem": "Sending people to Siberian camps was part of which of the following?",
      "choices": [
       "The collapse of the Russian government at the end of the First World War",
       "Large-scale emigration as a result of the First World War",
       "Stalin’s efforts to purge political rivals",
       "Colonization of land to increase fur and timber production"
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 25–27 refer to the following passage.",
     "items": [
      "“We see our people threatened by a mortal danger. The danger is that of a new religion. The church knows that it will have to account before God if the German people, unwarned, should turn away from Christ.",
      "The first commandment reads: I am the Lord Thy God. Thou shalt have no other gods before me. The new religion is a rebellion against the first commandment:",
      "• In it, the racial and folkish ideology becomes a myth. In it, blood and race, nationality, national honor, and the nation’s freedom of action become idols.",
      "• The faith in an ‘eternal Germany’ demanded by this religion replaces the faith in the eternal kingdom of our Lord and Savior Jesus Christ.",
      "• This false faith creates its gods in man’s image and essence. Such idolatry has nothing in common with positive Christianity. It is the expression of the Anti-Christ. . . .",
      "• The church must not bow to the new religion’s claim that the state can bind the individual’s conscience. . . . [Jesus Christ] alone can bind and loosen a man’s conscience.",
      "• Therefore the church must not allow itself to be pushed from the public sphere into some quiet corner of private piety, where, self-satisfied, it would betray its mission.”",
      {
       "src": "Declaration of a group of German Protestant pastors, Berlin, 1935"
      }
     ]
    },
    "questions": [
     {
      "stem": "Based on the passage and the context in which it was created, it can be inferred that German authorities likely viewed the group of pastors who made the declaration as",
      "choices": [
       "a politically useful group that could further the Nazification of the German religious establishment",
       "a tradition-based group whose members would be a receptive audience to Nazism’s political and social ideas",
       "a harmless pacifist group that could safely be left to its own devices",
       "a dangerous dissident group whose leaders must be targeted for reprisals and persecution"
      ],
      "answer": "D"
     },
     {
      "stem": "The passage is an example of which of the following regarding twentieth-century Christianity?",
      "choices": [
       "Attempts by Christian churches to formulate responses to the pressing political issues of the period",
       "An emphasis on social work and helping those in need in the works of church leaders and theologians",
       "Christian leaders’ adherence to conservative positions on matters related to gender roles and family life",
       "Debates over Christian churches’ role in the social and political life of an increasingly multicultural Europe"
      ],
      "answer": "A"
     },
     {
      "stem": "All of the following statements are factually accurate. Which would best explain why appeals such as the one in the passage had a limited effect on German public opinion in the 1930s?",
      "choices": [
       "Nazi ideology was also criticized by some leaders of the Catholic Church.",
       "Several other central and eastern European regimes espoused ideological positions similar to those criticized in the appeal.",
       "Protestantism was the religion of the majority of the German population.",
       "The German economy was in the process of recovering from the Great Depression."
      ],
      "answer": "D"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 28–30 refer to the image below.",
     "items": [
      {
       "caption": "Albrecht Dürer, Self-Portrait, 1500"
      },
      {
       "img": "images/y17-durer-selfportrait.jpg",
       "alt": "Albrecht Dürer, Self-Portrait, 1500"
      },
      {
       "note": "Bridgeman Images"
      },
      {
       "note": "The inscription reads: “I, Albrecht Dürer of Nuremberg painted myself thus, with undying colors, in my twenty-eighth year.”",
       "italic": true
      }
     ]
    },
    "questions": [
     {
      "stem": "The image is best understood in the context of which of the following developments during the Renaissance?",
      "choices": [
       "The emergence of Mannerist and Baroque artistic styles",
       "The development of cultural expressions that reflected nationalist values",
       "The revival of Greek and Roman classical styles",
       "The growth of individualist humanism in artistic expression"
      ],
      "answer": "D"
     },
     {
      "stem": "Based upon the image and its historical context, which of the following groups would have been most likely to commission paintings similar to Dürer’s Self-Portrait?",
      "choices": [
       "Commercial elites who sponsored art that emphasized everyday life and naturalist style",
       "Religious authorities who wished to emphasize the emotional aspects of Christian faith",
       "Government officials who sought to be portrayed as figures from classical mythology",
       "Protestant religious dissidents who favored art that broke with traditional Catholic motifs"
      ],
      "answer": "A"
     },
     {
      "stem": "By the late nineteenth century, artists’ self-portraits would increasingly emphasize which of the following?",
      "choices": [
       "Realist themes, which drew the audience’s attention to the suffering of the working class",
       "Exotic themes, which reflected Europe’s increased interaction with foreign cultures",
       "Positivist themes, which emphasized the improvement and perfectibility of humankind",
       "Subjective themes, which emphasized the portrayal of the artist’s inner emotional state"
      ],
      "answer": "D"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 31–34 refer to the following list of demands made by the rebel leaders of the War of the Communities of Castile, a joint commoner-noble revolt against the heavy taxes imposed in Spain by Holy Roman Emperor Charles V in 1520.",
     "items": [
      "“Officials: When a Cortes [the traditional advisory council of Castile] must be called, each district shall choose two officials to go to the Cortes, one from the nobility and one from the commoners . . . and each bishopric shall choose one cleric to go to the Cortes, and the knights shall choose two knights, and the [religious] orders shall choose two members of the orders, one Franciscan and one Dominican; and without all of these [representatives] there can be no Cortes.",
      "Justice: The king shall not be able to name a corregidor [district judge] in any place; instead, each city and town shall on the first day of the year nominate three nobles and three commoners, and the king or his governor shall choose one noble and one commoner [from among these nominees]; these two shall then be civil and criminal judges for three years.",
      "Money: The king shall not be allowed to take any coins out of the kingdom, nor gold or silver dust, and no coin can circulate or have value in Castile if it was not minted in the kingdom.",
      "War: Whenever the king wishes to make war he shall summon a Cortes, and inform its members . . . explaining the reasons for the war, so that they can see whether it is just or capricious. Without their consent the king cannot fight any war.”"
     ]
    },
    "questions": [
     {
      "stem": "In which of the following European powers in the early modern period was a consultative body similar to the Castilian Cortes most firmly entrenched?",
      "choices": [
       "France",
       "The Holy Roman Empire",
       "England",
       "The Ottoman Empire"
      ],
      "answer": "C"
     },
     {
      "stem": "All of the following statements are factually accurate. Which would best explain the rebels’ demands in the passage concerning money?",
      "choices": [
       "The massive inflow of silver from the Americas to Spain did not start until the second half of the sixteenth century.",
       "A significant number of economic transactions in sixteenth-century Castile were still in the form of barters or exchanges in kind.",
       "Charles’s election as Holy Roman Emperor in 1519 involved him in many expensive commitments outside Spain.",
       "Charles’s economic policies in Castile were consistent with the principles of mercantilism."
      ],
      "answer": "C"
     },
     {
      "stem": "The rebel leaders’ insistence on the importance of the Cortes best exemplifies which of the following processes in early modern Europe?",
      "choices": [
       "Attempts by corporate groups to use existing institutions of shared governance to resist royal encroachment",
       "Attempts by commercial and professional groups to obtain political power commensurate with their economic and social standing",
       "Attempts by the peasantry to maintain access to common lands and other resources threatened by privatization by members of the nobility",
       "Attempts by members of the landed aristocracy to reverse the trend toward greater use of professional or mercenary armies"
      ],
      "answer": "A"
     },
     {
      "stem": "Based on the rebels’ demands, it can be concluded that Charles V sought to implement in Castile policies characteristic of",
      "choices": [
       "constitutional monarchs",
       "Enlightened monarchs",
       "New monarchs",
       "elective monarchs"
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 35–37 refer to the tables below.",
     "items": [
      {
       "table": {
        "caption": "LITERACY AMONG DEFENDANTS IN SPANISH INQUISITION TRIALS, 1540–1600",
        "head": [
         "",
         "Diocese of Cuenca<br>percent literate",
         "Archdiocese of Toledo<br>percent literate"
        ],
        "rows": [
         [
          "<i>Males</i>",
          "35",
          "57"
         ],
         [
          "Urban",
          "41",
          "70"
         ],
         [
          "Rural",
          "34",
          "52"
         ],
         [
          "<i>Females</i>",
          "8",
          "4"
         ],
         [
          "Urban",
          "5",
          "7"
         ],
         [
          "Rural",
          "8",
          "2"
         ]
        ]
       }
      },
      {
       "table": {
        "caption": "LITERACY AMONG DEFENDANTS IN SPANISH INQUISITION TRIALS, 1601–1661",
        "head": [
         "",
         "Diocese of Cuenca<br>percent literate",
         "Archdiocese of Toledo<br>percent literate"
        ],
        "rows": [
         [
          "<i>Males</i>",
          "52",
          "62"
         ],
         [
          "Urban",
          "66",
          "70"
         ],
         [
          "Rural",
          "50",
          "57"
         ],
         [
          "<i>Females</i>",
          "28",
          "7"
         ],
         [
          "Urban",
          "57",
          "12"
         ],
         [
          "Rural",
          "21",
          "0"
         ]
        ]
       }
      },
      {
       "note": "Source: adapted from Sara T. Nalle, “Literacy and Culture in Early Modern Castile,” Past and Present, November, 1989, pp. 65-96."
      }
     ]
    },
    "questions": [
     {
      "stem": "Which of the following best accounts for the changes indicated in the tables between the literacy rates of the sixteenth century and those of the seventeenth century?",
      "choices": [
       "The revival of Classical humanist texts during the Renaissance",
       "Jesuit efforts to encourage the reading of the Bible",
       "The development of mandatory public education systems",
       "The development and spread of cheap printed educational materials, such as books for learning to read"
      ],
      "answer": "D"
     },
     {
      "stem": "Which of the following best accounts for the consistent difference between the male and the female literacy rates recorded in the tables?",
      "choices": [
       "The growth of monastic orders for women during the Catholic Reformation, such as the Ursulines",
       "The expectation that women would engage in different social and economic activities than men",
       "The weakening of traditional Catholic institutions as a result of the Protestant Reformation",
       "The practice of delaying marriage and postponing having children to improve economic prospects"
      ],
      "answer": "B"
     },
     {
      "stem": "A historian might use data such as those in the table to attempt to determine actual literacy rates in Spain in the period 1500–1700. All of the following statements are factually accurate. Which would LEAST limit the value of the data in the tables as a means of determining literacy rates?",
      "choices": [
       "The data in the tables cover a period of about 120 years (1540–1661).",
       "The defendants in cases brought by the Spanish Inquisition were not a representative sample of the Spanish population at the time.",
       "The compilers of the data in the table defined literacy as the ability to sign one’s name to a document.",
       "The percentages in the tables were based on a very small number of cases."
      ],
      "answer": "A"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 38–40 refer to the image below.",
     "items": [
      {
       "caption": "“The Making of Needles,” from the Encyclopedia, or a Systematic Dictionary of the Sciences, Arts, and Crafts, published in France between 1751 and 1772"
      },
      {
       "img": "images/y17-encyclopedia-needles.jpg",
       "alt": "The Making of Needles, from the Encyclopedia"
      },
      {
       "note": "Universal History Archive/UIG / Bridgeman Images"
      },
      {
       "note": "Caption states: “Needles: Cutting from steel wire (fig. 1), flattening end (fig. 4), stamping eye (fig. 2), punching eye (fig. 3), filing eye and pointing end (fig. 7), polishing (fig. 8). Specific monotonous task. Process virtually unchanged for 200 years.”",
       "italic": true
      }
     ]
    },
    "questions": [
     {
      "stem": "The system portrayed in the image best represents which of the following processes?",
      "choices": [
       "The expansion of capitalist investment in joint-stock companies",
       "The continuation of small-scale systems of production",
       "The development of mercantilist trade practices",
       "The periodic business downturns in industrial economies"
      ],
      "answer": "B"
     },
     {
      "stem": "Which of the following would most directly transform the production method depicted in the image?",
      "choices": [
       "The abolition of traditional guild restrictions",
       "The implementation of laissez-faire trade policies",
       "The development of mercantilist economic theories",
       "The mechanization of manufacturing"
      ],
      "answer": "D"
     },
     {
      "stem": "Which of the following was the likely purpose of the publication the image appeared in?",
      "choices": [
       "To advocate for socialist revolution",
       "To encourage French nationalism",
       "To spread Enlightenment principles",
       "To appeal to new consumer markets"
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 41–43 refer to the passages below.",
     "items": [
      {
       "label": "Source 1"
      },
      "“It is said that people have no more reason to fear forestalling, engrossing, and regrating* than they have to fear witchcraft. It is easy for a man to write a treatise in his closet; but if he would go to the distance of 200 miles from London and observe people at every avenue of a country town buying up butter, cheese, and all the necessaries of life they can lay hold of in order to prevent them from coming to market (which has happened to my knowledge), he would find that this is something more real and substantial than the crime of witchcraft. The country suffers most grievously by it.”",
      {
       "note": "*Crimes relating to price manipulation and hoarding under English Common Law"
      },
      {
       "src": "Lord Kenyon, Lord Chief Justice of England, in the court case of The King v. Waddington, 1800"
      },
      {
       "label": "Source 2"
      },
      "“The market settles, and alone can settle, that price. Market is the meeting and conference of the consumer and producer, when they mutually discover each others’ wants. Nobody, I believe, has observed with any reflection what market is, without being astonished at the truth, the correctness, the civility, the general equity with which the balance of wants is settled. They who wish the destruction of that balance, and would, by arbitrary regulations, decree, that insufficient production should not be compensated by increased price, directly lay their axe to the root of production itself.”",
      {
       "src": "Edward Law, attorney, in the court case of The King v. Waddington, 1800"
      }
     ]
    },
    "questions": [
     {
      "stem": "A historian could best use Lord Kenyon’s attitude toward witchcraft in Source 1 as evidence of which of the following?",
      "choices": [
       "The embrace of folk beliefs by elites",
       "The spread of Enlightenment thought",
       "The increasing involvement of women in commercial activities",
       "The ongoing social and religious tensions in England as a result of the Reformation"
      ],
      "answer": "B"
     },
     {
      "stem": "The ideas expressed in the passages above formed part of a debate about the merits of which of the following?",
      "choices": [
       "Mercantilism",
       "Socialism",
       "Laissez-faire liberalism",
       "Absolutism"
      ],
      "answer": "C"
     },
     {
      "stem": "During the late nineteenth century governments in western Europe most directly responded to the issue addressed in the passages in which of the following ways?",
      "choices": [
       "Abolishing traditional restrictions on labor",
       "Attempting to manage business cycles through taxation and regulation",
       "Nationalizing agricultural land and heavy industry",
       "Expanding colonies in Africa"
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 44–46 refer to the following maps.",
     "items": [
      {
       "img": "images/y17-maps-ottoman.jpg",
       "alt": "Maps of the Ottoman Empire, 1815 and 1914"
      }
     ]
    },
    "questions": [
     {
      "stem": "Which of the following was the most significant factor that contributed to the changes to Ottoman territory shown on the maps?",
      "choices": [
       "Western European efforts to halt the spread of Islam in Europe",
       "The spread of nationalism in the Balkans",
       "The economic and social disruptions caused by the industrialization of the Ottoman Empire",
       "The defeat of Napoleon by a coalition of conservative monarchies"
      ],
      "answer": "B"
     },
     {
      "stem": "The changes shown on the maps contributed most directly to",
      "choices": [
       "the destabilization of the European balance of power",
       "the dissolution of Austria-Hungary",
       "the modernization of the Russian Empire",
       "the greater integration of Eastern Europe into the global trade system"
      ],
      "answer": "A"
     },
     {
      "stem": "In the period 1815–1914, which of the following regions of Europe experienced political developments that most strongly contrasted with those shown on the maps?",
      "choices": [
       "Spain",
       "The British Isles",
       "France",
       "The Italian Peninsula"
      ],
      "answer": "D"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 47–49 refer to the passage below.",
     "items": [
      "“Experience has no value for the arrogant man; faith is nothing to him. He substitutes for faith a pretended individual conviction, and he dispenses with all inquiry and study. For inquiry and study appear too trivial to a mind that believes itself strong enough to embrace at one glance all questions and all facts. Laws have no value for him, because he has not made them. Besides, he thinks it would be beneath a man like him to recognize the rules established by earlier generations that he considers rude and ignorant. Instead, he believes that power resides in himself alone.”",
      {
       "src": "Klemens von Metternich, letter to Tsar Alexander I, 1820"
      }
     ]
    },
    "questions": [
     {
      "stem": "Which of the following is Metternich most strongly critiquing in his letter to the tsar?",
      "choices": [
       "Utilitarianism",
       "Utopian socialism",
       "Mercantilism",
       "Skepticism"
      ],
      "answer": "D"
     },
     {
      "stem": "Based on the letter and its context, Metternich most clearly supported which of the following principles?",
      "choices": [
       "The maintenance of traditional social structures and values",
       "The right to national self-determination",
       "The application of scientific laws to society",
       "The redistribution of resources and wealth"
      ],
      "answer": "A"
     },
     {
      "stem": "Metternich likely expressed these sentiments in a letter to the tsar because of",
      "choices": [
       "Russia’s close cooperation with Austria against the Ottoman Empire",
       "Russia’s strong support for the Concert of Europe after the Congress of Vienna",
       "Russia’s support for Slavic independence movements in the Balkans",
       "Russia’s expansionist aims in Central and East Asia"
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 50–52 refer to the image below.",
     "items": [
      {
       "caption": "Photo of a unit of the Mocidade Portuguesa Feminina (Portuguese Women’s Youth Organization) in front of a monument to Henry the Navigator, Lisbon, late 1930s."
      },
      {
       "img": "images/y17-photo-mocidade.jpg",
       "alt": "Photo of the Mocidade Portuguesa Feminina, Lisbon, 1930s"
      },
      {
       "note": "Z1 Collection / Alamy"
      }
     ]
    },
    "questions": [
     {
      "stem": "The image most clearly represents which of the following trends of the interwar period?",
      "choices": [
       "Growing communist sympathy in western Europe",
       "Increased United States influence on European affairs",
       "Growing discontent with colonial European rule",
       "Increased nationalism reinforced through militarism"
      ],
      "answer": "D"
     },
     {
      "stem": "The ideology represented in the image had which of the following effects on neighboring Spain?",
      "choices": [
       "Spanish industrialization lagged behind that of the rest of western Europe.",
       "Spain lost its remaining colonies in the Americas.",
       "Germany and Italy intervened in the Spanish Civil War.",
       "Spain joined the NATO alliance after the Second World War."
      ],
      "answer": "C"
     },
     {
      "stem": "The organization in the image is best understood as a continuation of which of the following?",
      "choices": [
       "The emergence of second-wave feminism",
       "The political and military mobilization of women during the First World War",
       "The success of the women’s suffrage movement",
       "The growth of new concepts of marriage and motherhood"
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 53–55 refer to the passage below.",
     "items": [
      "“Unfortunately, Americans focus more on Soviet military hardware than on [Soviets’] limited political prestige. That is responsible for your overestimation of Soviet power, as if power in history is the same as force of arms! What myopia and short-sightedness. There is more power in rock music, videos, blue jeans, fast food, news networks and TV satellites than in the entire Red Army.”",
      {
       "src": "Régis Debray, leftist French philosopher, 1986"
      }
     ]
    },
    "questions": [
     {
      "stem": "Which of the following events of the 1980s or 1990s best supported Debray’s assessment of the relative importance of cultural capital versus military power?",
      "choices": [
       "Soviet leader Mikhail Gorbachev’s policy of glasnost",
       "The Soviet defeat in Afghanistan",
       "The Communist crackdown on the Polish Solidarity labor movement",
       "The outbreak of ethnic violence in Yugoslavia"
      ],
      "answer": "A"
     },
     {
      "stem": "The cultural trends referenced by Debray were mostly a result of which of the following?",
      "choices": [
       "The breakdown of economic and cultural barriers as a result of the formation of the European Economic Community",
       "The increasing influence of American popular culture in Europe after the Second World War",
       "The growing influence of French existentialist and postmodernist philosophers on Western European culture",
       "The propaganda spread by the Soviet bloc to undermine European democracies"
      ],
      "answer": "B"
     },
     {
      "stem": "All of the following statements about Debray are factually accurate. Which one would be most useful in evaluating his perspective in the passage?",
      "choices": [
       "He participated in a guerrilla movement alongside Che Guevara, the Marxist revolutionary, in Bolivia during the 1960s.",
       "He founded an academic discipline dedicated to the scientific study of the spread of ideas through mass media.",
       "He became more politically moderate and concerned with religious affairs later in life.",
       "He supported the 2003 law prohibiting the wearing of Muslim head scarves in French schools."
      ],
      "answer": "B"
     }
    ]
   }
  ]
 },
 "ced": {
  "title": "AP European History Practice Exam (Course Description)",
  "short": "CED Practice Exam",
  "sets": [
   {
    "passage": {
     "intro": "Questions 1–4 refer to the passage below.",
     "items": [
      "“Assume, O men of the German lands, that ancient spirit of yours with which you so often confounded and terrified the Romans and turn your eyes to the frontiers of Germany; collect her torn and broken territories. Let us be ashamed, ashamed I say, to have placed upon our nation the yoke of slavery. . . . O free and powerful people, O noble and valiant race. . . . To such an extent are we corrupted by Italian sensuality and by fierce cruelty in extracting filthy profit that it would have been far more holy and reverent for us to practice that rude and rustic life of old, living within the bounds of self-control, than to have imported the paraphernalia of sensuality and greed which are never sated, and to have adopted foreign customs.”",
      {
       "src": "Conrad Celtis, oration delivered at the University of Ingolstadt, 1492"
      }
     ]
    },
    "questions": [
     {
      "stem": "The passage above most clearly shows the influence of which of the following trends in fifteenth-century Europe?",
      "choices": [
       "The development of natural philosophy based on inductive and deductive reasoning",
       "The revival of classical learning and the development of Northern humanism",
       "The continued reliance on traditional supernatural explanations of the world",
       "The development of Baroque dramatic forms to enhance the stature of elites"
      ],
      "answer": "B"
     },
     {
      "stem": "Celtis’ discussion of Italian influence in the German lands is most similar to which of the following?",
      "choices": [
       "Machiavelli’s criticism of Italian political systems in The Prince",
       "Galileo’s science-based inquiries that threatened the authority of Catholic world views",
       "Erasmus’ arguments in favor of religious toleration and criticizing traditional superstitions",
       "Martin Luther’s criticisms of the Catholic Church in his Ninety-five Theses"
      ],
      "answer": "D"
     },
     {
      "stem": "The political condition of Germany described in the passage did not change until",
      "choices": [
       "1789",
       "1815",
       "1871",
       "1945"
      ],
      "answer": "C"
     },
     {
      "stem": "Which of the following groups in the nineteenth century would most likely have agreed with the sentiments in the passage?",
      "choices": [
       "Industrial capitalists",
       "Radical anarchists",
       "Romantic nationalists",
       "Utopian socialists"
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 5–8 refer to the passage below.",
     "items": [
      "“Anno Domini 1618, a great comet appeared in November. To see the thing was terrible and strange, and it moved me and changed my disposition so that I started to write, because I thought that it meant something big would occur, as then really did happen. . . . Anno Domini 1619, Ferdinand became the Holy Roman Emperor, under whom a great persecution happened through war, unrest, and the spilling of the blood of Christians. . . . First, he started a big war in Bohemia, which he then oppressed and subjugated under his religion, then almost the whole of Germany was conquered, all of which I can hardly describe and explain.”",
      {
       "src": "Hans Herberle, shoemaker in Ulm, southern Germany, personal chronicle compiled in the 1630s"
      }
     ]
    },
    "questions": [
     {
      "stem": "The conflict that Herberle describes in his chronicle resulted in which of the following?",
      "choices": [
       "The establishment of several religiously pluralistic and tolerant states within the German-speaking regions",
       "The weakening of the Holy Roman Empire and the strengthening of smaller sovereign states within its boundaries",
       "The virtual extinction of all Christian denominations except Lutheranism and Roman Catholicism within the German-speaking regions",
       "The political unification of most of the German-speaking regions under a Protestant, rather than a Catholic monarch"
      ],
      "answer": "B"
     },
     {
      "stem": "Based on the passage, which of the following can be safely inferred about Herberle’s religious affiliation?",
      "choices": [
       "He was a member of a Lutheran church.",
       "He was a member of a Calvinist church.",
       "He was not a member of any established church.",
       "He was not Roman Catholic."
      ],
      "answer": "D"
     },
     {
      "stem": "A historian could best use Herberle’s discussion of the comet as evidence for which of the following features of early modern intellectual life?",
      "choices": [
       "The diffusion of new scientific knowledge in the general population of Europe",
       "The continued popularity of astrology among members of the elite",
       "The persistence of a traditional view of the world as governed by supernatural forces",
       "The growing tension between religious and scientific explanations of natural phenomena"
      ],
      "answer": "C"
     },
     {
      "stem": "The ability of someone of Herberle’s social status in seventeenth-century Germany to read and write was most likely the result of which of the following?",
      "choices": [
       "The diffusion of Renaissance humanist ideas to areas outside Italy",
       "The Protestant Reformation’s emphasis on individual study of the Bible",
       "The establishment of mandatory systems of national education",
       "The growth of representative forms of government as alternatives to absolutism"
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 9–12 refer to the passage below.",
     "items": [
      "“The Natives of New-Holland may appear to some to be the most wretched people upon Earth, but in reality they are far happier than we Europeans; being wholly unacquainted not only with the superfluous but the necessary Conveniencies so much sought after in Europe, they are happy in not knowing the use of them. They live in a Tranquility which is not disturbed by the Inequality of Condition: The Earth and sea of their own accord furnishes them with all things necessary for life, they covet not Magnificent Houses, Household-stuff, etc., they live in a warm and fine Climate and enjoy a very wholesome Air, so that they have very little need of Clothing. . . . Many to whom we gave Cloth left it carelessly upon the beach and in the woods as a thing they had no manner of use for. In short they seemed to set no Value upon any thing we gave them, nor would they ever part with any thing of their own for any one article we could offer them; this in my opinion argues that they think themselves provided with all the necessaries of Life and that they have no superfluities.”",
      {
       "src": "James Cook, British naval officer, describing the inhabitants of Australia, 1770"
      }
     ]
    },
    "questions": [
     {
      "stem": "Accounts of non-European peoples similar to Cook’s portrayal of the inhabitants of Australia contributed most directly to the development of which of the following?",
      "choices": [
       "Romanticism",
       "Enlightenment rationalism",
       "Positivism",
       "Nationalism"
      ],
      "answer": "A"
     },
     {
      "stem": "Compared to Cook’s portrayal of the inhabitants of Australia in the late eighteenth century, the predominant European view of non-European peoples in the late nineteenth century had changed in which of the following ways?",
      "choices": [
       "Europeans in the late nineteenth century tended to view less structured and hierarchical societies as more desirable political models.",
       "Europeans in the late nineteenth century tended to view lack of technological development as evidence of cultural inferiority.",
       "Europeans in the late nineteenth century tended to view economically undeveloped societies as fairer and more just.",
       "Europeans in the late nineteenth century tended to view climate as less significant than other factors in determining social development."
      ],
      "answer": "B"
     },
     {
      "stem": "Cook’s observations concerning the material culture of the inhabitants of Australia most clearly reflect the influence of which of the following developments in Europe?",
      "choices": [
       "The decline in power of the landed aristocracy relative to commercial elites",
       "The increase in agricultural productivity known as the Agricultural Revolution",
       "Protestant reaction against ornate forms of decoration and religious imagery",
       "The expanded availability and use of consumer goods"
      ],
      "answer": "D"
     },
     {
      "stem": "Cook’s voyages were primarily a result of which of the following eighteenth-century developments?",
      "choices": [
       "Competition among European powers to create commercial empires",
       "Rivalries between Catholic and Protestant countries to gain converts overseas",
       "Private support for scientific exploration",
       "Efforts to secure new sources of labor for industrialization"
      ],
      "answer": "A"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 13–15 refer to the song lyrics below.",
     "items": [
      {
       "poem": [
        "“To Versailles like bragging lads",
        "We brought with us all our guns",
        "We had to show, though we were but women,",
        "A courage that no one can reproach us for.",
        "Now we won’t have to go so far",
        "When we want to see our King.",
        "We love him with a love without equal,",
        "Since he’s come to live in our Capital.”"
       ]
      },
      {
       "src": "Song of the poissardes (Paris market women), October 1789"
      }
     ]
    },
    "questions": [
     {
      "stem": "The events referred to in the song led most directly to which of the following?",
      "choices": [
       "The formalization of a constitutional monarchy in France",
       "The creation of a republican government in France",
       "The installation of Napoleon as Emperor of the French",
       "The restoration of the Bourbon monarchy"
      ],
      "answer": "A"
     },
     {
      "stem": "The poissardes and other participants in the events described in the song were motivated most strongly by which of the following?",
      "choices": [
       "An economic crisis brought about by food shortages",
       "The desire to institute free-market principles in the French economy",
       "The failure of France to gain substantial advantages from its wars with Britain",
       "The fear that Enlightenment ideas about government would undermine the basis of monarchy"
      ],
      "answer": "A"
     },
     {
      "stem": "The participation of women such as the poissardes led to which of the following during the early phases of the French Revolution?",
      "choices": [
       "Wage equality for women",
       "Permanent legal equality for women, but no political rights",
       "Temporary improvements in women’s legal status",
       "Loss of rights previously held by women"
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 16–18 refer to the map below.",
     "items": [
      {
       "img": "images/ced-map-polder.jpg",
       "alt": "1664 map of the Beemster polder"
      },
      {
       "note": "Beemsterlants Caerte by Daniel van Breen. Courtesy of the Zuiderzee Museum."
      },
      {
       "note": "Above is a 1664 map of a 28-square-mile polder, an example of farmland reclaimed from wetlands in the Netherlands during the seventeenth century. The square grid represents intersecting roads and drainage canals; the rectangular strips represent individual family landholdings."
      }
     ]
    },
    "questions": [
     {
      "stem": "Infrastructure projects such as the one depicted on the map are best understood in the context of which of the following?",
      "choices": [
       "The diffusion of new agricultural technology from European overseas colonies",
       "The negative impact of the reimposition of serfdom on agricultural productivity",
       "The intensification of agricultural production in response to the development of a market economy",
       "The continued importance of hierarchy and status in rural European society"
      ],
      "answer": "C"
     },
     {
      "stem": "By the mid-eighteenth century, developments in agriculture similar to the ones reflected in the map led to which of the following in some parts of western Europe?",
      "choices": [
       "Rural overpopulation and migration to the cities",
       "An intensification of the pattern of Malthusian demographic cycles",
       "The decline of patriarchy and the adoption of more egalitarian gender roles among the peasantry",
       "The emergence of a new pattern of delaying marriage and childbirth as a means to limit rural birthrates"
      ],
      "answer": "A"
     },
     {
      "stem": "In addition to new patterns of landownership and land use, which of the following factors had the greatest impact on western European agriculture in the seventeenth and eighteenth centuries?",
      "choices": [
       "The beginning of the cooling period known as the Little Ice Age",
       "The increasing cultivation of new crops brought from the Americas",
       "The increasing use of synthetic chemical fertilizers",
       "The increasing use of steam engine technology in agriculture"
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 19–22 refer to the passage below.",
     "items": [
      "“The purpose of the geography curriculum was to come to know the narrower and broader Fatherland and to awaken one’s love of it. . . . From [merely learning the names of] the many rivers and mountains one will not see all the Serbian lands, not even the heroic and unfortunate field of Kosovo [on which the Ottomans defeated the Serbs in 1389]; from the many rivers and mountains children do not see that there are more Serbs living outside Serbia than in Serbia; they do not see that Serbia is surrounded on all sides by Serbian lands; from the many mountains and rivers we do not see that, were it not for the surrounding Serbs, Serbia would be a small island that foreign waves would quickly inundate and destroy; and, if there were no Serbia, the remainder of Serbdom would feel as though it did not have a heart.”",
      {
       "src": "Report to the Serbian Teachers’ Association, 1911–1912"
      }
     ]
    },
    "questions": [
     {
      "stem": "The report best reflects which of the following goals of public education systems in the period before the First World War?",
      "choices": [
       "Heightening awareness of the dangers of international conflict",
       "Greater appreciation of the Ottoman legacy in the Balkans",
       "Training bureaucrats for imperial posts",
       "Instilling feelings of nationalism"
      ],
      "answer": "D"
     },
     {
      "stem": "The conditions referred to in the report were most directly a result of which of the following developments?",
      "choices": [
       "The transformation of the Habsburg Empire into the dual monarchy of Austria-Hungary",
       "The emergence of new Balkan states as the Ottoman Empire declined",
       "The growth of international tensions following Bismarck’s dismissal as chancellor of Germany",
       "The increase of economic competition between imperial powers for industrial resources"
      ],
      "answer": "B"
     },
     {
      "stem": "Sentiments similar to those expressed in the report most directly contributed to which of the following developments in the late twentieth century?",
      "choices": [
       "The development of the European Union during the Cold War",
       "The development of COMECON in Eastern Europe",
       "Ethnic conflict after the collapse of communism",
       "The move by European nations to relinquish their colonies"
      ],
      "answer": "C"
     },
     {
      "stem": "In the interwar period, educators in which of the following countries would most likely have had a view of geography education similar to that expressed in the passage?",
      "choices": [
       "Germany",
       "Great Britain",
       "France",
       "The Soviet Union"
      ],
      "answer": "A"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 23–26 refer to the passage below.",
     "items": [
      "“Twentieth-century Fascism is a byproduct of disintegrating liberal democracy. Loss of hope in the possibilities of existing order and society, disgust with their corruption and ineffectiveness, above all the society’s evident loss of confidence in itself, all these produce or spur a revolutionary mood in which the only issue lies in catastrophic action—but always with a strong social tinge: ‘I place my only hope in the continuation of socialist progress through fascisms,’ writes Drieu [a French Fascist author of the 1930s]. And the editor of the French Fascist publication, the Insurgent, Jean-Pierre Maxence, would call for insurgents of all parties to join ‘the front of united youth, for bread, for grandeur and for liberty, in immense disgust with capitalist democracy.’ From this angle, as from many others, Fascism looks very much like the Jacobinism of our time.”",
      {
       "src": "Eugen Weber, historian, Varieties of Fascism, 1964"
      }
     ]
    },
    "questions": [
     {
      "stem": "Which of the following features of the French Revolution would best support Weber’s argument comparing Fascism to Jacobinism?",
      "choices": [
       "The passage of laws ending the hereditary privileges of the nobility",
       "Napoleon’s seizure of power from the Directory",
       "The wars to protect Revolutionary France from foreign invasion",
       "The economic price and wage controls imposed during the Reign of Terror"
      ],
      "answer": "D"
     },
     {
      "stem": "Weber’s argument linking Fascism and Jacobinism implies that he was influenced by which of the following?",
      "choices": [
       "Marxist materialist analysis of social change and historical development",
       "Social Darwinist belief in the importance of struggle in historical progress",
       "Positivist emphasis on the role of technology in shaping human affairs",
       "Post-modernist subjectivist critiques of the ethos of western society"
      ],
      "answer": "A"
     },
     {
      "stem": "Which of the following would most contradict Weber’s thesis concerning the fundamental character of Fascism?",
      "choices": [
       "Mussolini’s membership in the Italian Socialist Party prior to founding the Italian Fascist movement",
       "The spread of Fascism to eastern European countries in the 1930s",
       "The growth of National Socialism in Germany during the economic crisis of the early 1930s",
       "Franco’s support for traditional Catholic values in his Spanish Fascist movement"
      ],
      "answer": "D"
     },
     {
      "stem": "Which of the following would best explain the appeal of Fascism in France alluded to in the passage?",
      "choices": [
       "The French alliance with Italy during the First World War",
       "Political instability in France after the First World War",
       "Lingering anti-Semitism in France in the aftermath of the Dreyfus affair",
       "The incorporation of Alsace into France after the First World War"
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 27–29 refer to the 1950 poster, shown below, created by the French Communist Party.",
     "items": [
      {
       "img": "images/ced-poster-1950.jpg",
       "alt": "1950 French Communist Party poster"
      },
      {
       "note": "TRANSLATION: “No, France will not be a colonized country! Americans stay in America!”"
      }
     ]
    },
    "questions": [
     {
      "stem": "The attitude exemplified by the poster was likely LEAST influenced by which of the following?",
      "choices": [
       "Soviet influence over Western European communist parties during the Cold War",
       "The Marshall Plan",
       "The creation of NATO",
       "The creation of the United Nations"
      ],
      "answer": "D"
     },
     {
      "stem": "The creators of the poster also likely opposed which of the following?",
      "choices": [
       "Greater involvement of women in politics and education",
       "The expansion of social welfare programs",
       "The continued French government of Algeria",
       "The expansion of Soviet economic influence in Eastern Europe"
      ],
      "answer": "C"
     },
     {
      "stem": "The political sentiment expressed in the poster would have the greatest influence on which of the following?",
      "choices": [
       "The collapse of the Soviet Union",
       "The development of the European Union",
       "The increase in the number of migrant laborers in Western Europe",
       "The student rebellions of 1968"
      ],
      "answer": "D"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 30–32 refer to the passages from religious texts below.",
     "items": [
      "“No matter how learned a woman may be, silence her in matters of faith and the Church. For it is certain what the ancients said, that which makes a woman prettiest is silence on her lips for all conversation, and particularly for the mysteries of holiness and so she is not to be a teacher of the doctrine of the Sacred Scriptures.”",
      {
       "src": "Fernando Valdés, Spain, 1537"
      },
      "“It pleased our Lord and Savior Jesus Christ. . . being free from original and all other sins, from the time of his conception till the hour of his death, to be begotten of a woman, born of a woman, nourished of a woman, obedient to a woman; and that he healed women, pardoned women, comforted women. . . and after his resurrection appeared first to a woman, and sent a woman to declare his most glorious resurrection to the rest of his Disciples.”",
      {
       "src": "Emilia Lanier, England, 1611"
      }
     ]
    },
    "questions": [
     {
      "stem": "The passages are best understood in the context of which of the following?",
      "choices": [
       "The humanist debate over education and the rights of women",
       "The debate over the role of women in society prompted by the Reformation",
       "The wars between Spain and England during the sixteenth and seventeenth centuries",
       "The revival of the study of classical texts"
      ],
      "answer": "B"
     },
     {
      "stem": "Valdés’ argument reflects which of the following developments of this period?",
      "choices": [
       "The concern over women’s emigration to the New World",
       "The affirmation by the Roman Catholic Church hierarchy of women’s subordination in matters of religion",
       "The Renaissance humanist revival of Greek and Roman attitudes towards women",
       "The growing popularity of monasticism for Catholic women"
      ],
      "answer": "B"
     },
     {
      "stem": "Lanier’s publication of an argument for increased respect for women was made possible by which of the following?",
      "choices": [
       "The spread of literacy and personal engagement with religious texts",
       "Elizabeth I’s use of magisterial religious authority on behalf of women",
       "The opening of clerical positions to women",
       "New scientific writings that challenged classical learning"
      ],
      "answer": "A"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 33–36 refer to the graph below.",
     "items": [
      {
       "img": "images/ced-graph-seed-yields.png",
       "alt": "Graph of seed yields for wheat and barley, 1600–1850"
      },
      {
       "note": "Source: Adapted from Norman J. G. Pounds, A Historical Geography of Europe, Volume II: 1500-1840, Cambridge University Press, 1979, p. 182."
      },
      {
       "note": "*Seed yield (or crop yield) is the number of grain seeds harvested for each seed sown."
      }
     ]
    },
    "questions": [
     {
      "stem": "The patterns shown on the graph most directly contributed to which of the following?",
      "choices": [
       "The increasing number of Europeans emigrating to the Americas",
       "The early industrialization of Britain and the Low Countries",
       "The large size of France’s population",
       "The increasing importance of eastern Europe as a grain exporter"
      ],
      "answer": "B"
     },
     {
      "stem": "In the late 1700s and early 1800s, liberal political economists in western Europe used information similar to the data shown in the graph to argue that",
      "choices": [
       "governments should require landholders to make agricultural improvements",
       "the export of food crops and other agricultural products should be restricted",
       "agricultural work had moral and physical benefits that were superior to those of industrial labor",
       "abolition of common agricultural land holdings would result in greater agricultural productivity"
      ],
      "answer": "D"
     },
     {
      "stem": "Apart from the changes in seed yield shown on the graph above, which of the following most directly affected Europe’s ability to feed itself in the period 1600-1800?",
      "choices": [
       "The creation of large cash-crop plantations in the Americas",
       "The cultivation of New World crops in Europe",
       "The widespread mechanization of agriculture",
       "The decreasing tendency of armies to target civilian populations during wartime"
      ],
      "answer": "B"
     },
     {
      "stem": "Based on the information in the graph, which of the following regions was most likely to avoid the Malthusian trap concerning food supply and population?",
      "choices": [
       "Great Britain and the Low Countries",
       "France, Spain, and Italy",
       "Central Europe and Scandinavia",
       "Eastern Europe"
      ],
      "answer": "A"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 37–39 refer to the political cartoon below.",
     "items": [
      {
       "img": "images/ced-cartoon-border.jpg",
       "alt": "1834 German cartoon, Border Embarrassment"
      },
      {
       "note": "“Border Embarrassment,” cartoon published in a German newspaper, 1834."
      },
      {
       "note": "Photo Credit: bpk, Berlin/Art Resource, NY"
      },
      "The cartoon shows adjacent entry and exit border crossings of Lippe-Schaumberg, one of the small states in northwestern Germany.",
      "Cartoon caption: “You see, Mr. Border Official, that I have nothing to declare, because what’s in the back of the cart has not yet crossed Lippe’s border, there is nothing in the middle, and what’s in the front of the cart has already cleared Lippe’s border.”"
     ]
    },
    "questions": [
     {
      "stem": "At the time of the cartoon’s publication, the political conditions referred to had been most recently reaffirmed by",
      "choices": [
       "the French Revolution",
       "the abolition of the Holy Roman Empire by Napoleon",
       "the settlement at the Congress of Vienna",
       "the July Revolution of 1830"
      ],
      "answer": "C"
     },
     {
      "stem": "Which of the following conclusions is best supported by the cartoon?",
      "choices": [
       "German liberals regarded the status quo in the German states as an obstacle to progress.",
       "German conservatives were largely caught off guard by the outbreak of the Revolutions of 1848.",
       "There was a strong resentment against Schaumburg-Lippe and the other small German states among people living in the larger German states, such as Prussia and Bavaria.",
       "Regional, local, and state-specific loyalties made the emergence of a common German identity impossible."
      ],
      "answer": "A"
     },
     {
      "stem": "Which of the following developments in nineteenth-century German history was most directly a response to the concerns expressed in the cartoon?",
      "choices": [
       "The establishment of social welfare legislation providing old-age and disability pensions for workers",
       "The creation of the Zollverein, a customs union under Prussian leadership, which facilitated trade and hastened industrialization",
       "The Prussian government’s support for the creation of an extensive rail network in German states",
       "The persistence of primitive agricultural practices and landowning patterns in some parts of the German lands"
      ],
      "answer": "B"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 40–43 refer to the passage below.",
     "items": [
      "“First, the natives of India, so far as I have seen, and speaking generally, are barbarians. It is necessary that you should have special care for all your sons of the Jesuit Order in India in commending them to God our Lord continually, for you know what a great toil it is to have to do with people who through their very habitual evil living neither know God nor obey reason. . . .",
      "I see clearly, my only Father, by my experience here, that no road is opening for the perpetuation of the Jesuit Order among the natives. Christianity will last among them only as long as we who are here or those whom you will send from Europe will last and live. . . .",
      "The Portuguese here control only the sea and the places on the seashore, and so they are not masters [in the interior] but only in the places where they live. The native Indians are not at all inclined to the things of [Christianity] but rather abhor them greatly. It irks them mortally when we speak to them and ask them to become Christians.” Francis Xavier, Spanish Jesuit priest in India, letter to Ignatius Loyola, head of the",
      {
       "src": "Francis Xavier, Spanish Jesuit priest in India, letter to Ignatius Loyola, head of the Society of Jesus, 1549"
      }
     ]
    },
    "questions": [
     {
      "stem": "The Portuguese presence in India most directly resulted from which of the following?",
      "choices": [
       "The desire to obtain greater access to precious metals and luxury goods",
       "The desire to secure a supply of labor for expanding manufacturing in Europe",
       "The desire to create new plantations for the production of cash crops",
       "The desire to establish new markets for European manufactured goods"
      ],
      "answer": "A"
     },
     {
      "stem": "Xavier’s views in the second paragraph support which of the following conclusions about the period 1450–1648?",
      "choices": [
       "Christianization efforts were more successful in Asia than in the Americas.",
       "Christianization was used to justify the African slave trade.",
       "Christianization was generally in conflict with mercantilist policies.",
       "Christianization both depended on and legitimized European colonial expansion."
      ],
      "answer": "D"
     },
     {
      "stem": "Xavier’s views of indigenous populations as expressed in the passage were most similar to views commonly held by late-nineteenth-century Europeans in which of the following ways?",
      "choices": [
       "Both views reflected a fear of native influences on Christianity.",
       "Both views reflected a sense of admiration for foreign cultures.",
       "Both views reflected a sense of cultural superiority.",
       "Both views reflected a sense of moral ambiguity concerning colonization."
      ],
      "answer": "C"
     },
     {
      "stem": "The religious order of which Xavier was a member was important in the history of sixteenth-century Europe primarily because it",
      "choices": [
       "challenged Protestant teachings and helped revive the Church during the Catholic Reformation",
       "studied Greek and Roman texts but challenged secular values in Renaissance humanism",
       "ensured that Catholic institutions remained outside monarchical control",
       "revived universities in eastern Europe"
      ],
      "answer": "A"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 44–46 refer to the poem below.",
     "items": [
      {
       "poem": [
        "“The foundations of old knowledge have collapsed.",
        "Wise men have probed the depths of the earth;",
        "Treasures of buried strata furnish the proofs of creation.",
        "[Religion] is no longer the apex of fulfillment for the intelligent.",
        "Atlas does not hold up the earth, nor is Aphrodite divine;",
        "Plato’s wisdom cannot explain the principles of evolution.",
        "‘Amr is no slave of Zayd, nor is Zayd ‘Amr’s master *—",
        "Law depends upon the principle of equality.",
        "Neither the fame of Arabia, nor the glory of Cairo remains.",
        "This is the time for progress; the world is a world of science;",
        "Is it possible to maintain society in ignorance?”"
       ]
      },
      {
       "src": "Sâdullah Pasha, Ottoman intellectual, The Nineteenth Century, poem, 1878"
      },
      {
       "note": "* Zayd and ‘Amr are Muslim names traditionally used in Islamic legal opinions in the generic sense of “John Doe 1” and “John Doe 2.”"
      }
     ]
    },
    "questions": [
     {
      "stem": "Based on the poem, it can be inferred that Sâdullah Pasha was most influenced by which of the following?",
      "choices": [
       "Social Darwinism",
       "Positivism",
       "Romantic nationalism",
       "Abolitionism"
      ],
      "answer": "B"
     },
     {
      "stem": "The last three lines of the poem best illustrate which of the following aspects of Europe’s relationship with the rest of the world in the late nineteenth century?",
      "choices": [
       "European imperial encroachments provoked a cultural backlash and a rejection of Western values in many areas of Africa and Asia.",
       "Colonial subjects began organizing politically to overthrow European rule.",
       "Many countries were made dependent on Europe economically and politically through treaties and trade agreements.",
       "Adoption of Western ideas caused many non-Western peoples to call for the modernization of their own societies and states."
      ],
      "answer": "D"
     },
     {
      "stem": "By the 1920s and 1930s, the ideas concerning science and progress reflected in the poem underwent which of the following transformations?",
      "choices": [
       "The ideas were largely rejected by non-Western leaders as incompatible with indigenous norms and cultures.",
       "The ideas were largely supplanted by a revival of religious sentiment in the wake of the First World War.",
       "The ideas came to be regarded with suspicion by many European intellectuals in the light of subsequent scientific discoveries and political events.",
       "The ideas were regarded with increasing hostility by European intellectuals in the wake of growing anticolonial movements in Asia and Africa."
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 47–49 refer to the following passage.",
     "items": [
      "“To Commissar Lenin, Chairman of the Russian Socialist Republic:",
      "We middle-and poor-peasant laborers have never been either bourgeois or speculator-profiteers, or drunkards, or pickpockets, or lazybones-parasites of the upper class. . . . [The Bolshevik provincial authorities] have not tried to raise and improve the working level of the people. All they do is extort, rob, and take away what has been amassed by our hard and persistent labor and thrift. Let’s take for example some families in the village: the first one is the Kulikhins, who have three plots of land and seven healthy, strong men; they abandoned their land and house and wander around and beg. Another family—the Obraztsovas—is a woman who has young children and old folks to take care of; yet she plows the land herself and takes care of everything else. And now it turns out that that the Kulikhins are considered poor peasants [and are protected by the Bolsheviks], while the Obraztsovas are classified as bourgeois: grain and livestock were taken from them and the authorities imposed on them heavy requisitions and taxes. And so the poor lazybones grow richer than the rest of us a thousand times. The wealth of the peasant is accumulated through thrift. So where is justice? There is no such thing.”",
      {
       "src": "Petition from peasants from the Vologda region, Russia, 1920"
      }
     ]
    },
    "questions": [
     {
      "stem": "The petition best supports which of the following conclusions?",
      "choices": [
       "Most Russian peasants opposed the Bolshevik Revolution and supported the Whites in the Russian Civil War.",
       "Peasant notions of social status and social hierarchy were at odds with Bolshevik notions of class formation and class consciousness.",
       "There was a large surplus of arable land in the Russian countryside that was not being cultivated.",
       "Despite the revolution, peasant ideas of ethical living and proper behavior were still deeply influenced by Christian teachings."
      ],
      "answer": "B"
     },
     {
      "stem": "Which of the following was most directly a cause of the inequalities in land ownership among the Russian peasantry referred to by the petitioners?",
      "choices": [
       "Peter the Great’s westernizing reforms",
       "The abolition of serfdom",
       "The Revolution of 1905",
       "Lenin’s New Economic Policy"
      ],
      "answer": "B"
     },
     {
      "stem": "The Bolshevik policies decried by the petitioners in the passage would be carried to their logical conclusion in which later Soviet policy?",
      "choices": [
       "The policy of allowing limited private market activity under the New Economic Policy",
       "The policy of rapid industrialization under the Five Year Plans",
       "The policy of liquidating the kulaks as a class and the formation of collective farms",
       "The policy of mass incarceration of political opponents in the Gulag"
      ],
      "answer": "C"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 50–52 refer to the painting below.",
     "items": [
      {
       "img": "images/ced-painting-dix.jpg",
       "alt": "Painting by Otto Dix"
      },
      {
       "note": "© 2013 Artists Rights Society (ARS), New York / VG Bild-Kunst, Bonn; bpk, Berlin / Bayerische Staatsbibliothek, Munich, Germany / Art Resource, NY"
      }
     ]
    },
    "questions": [
     {
      "stem": "The painting is an example of which of the following developments in modernist European art?",
      "choices": [
       "Artists’ turn to dreams and the subconscious as a source of inspiration",
       "Artists’ abandonment of realistic representation in order to convey internal emotional states",
       "Artists’ glorification of technological progress in the machine age",
       "Artists’ exploration of non-European cultures as a source of ne w subject matters and styles"
      ],
      "answer": "B"
     },
     {
      "stem": "The situation of war veterans such as those depicted in the image was most effectively used to sway public opinion during the interwar period by which of the following groups in Germany?",
      "choices": [
       "Right-wing nationalists critical of government ineffectiveness",
       "Pacifists wishing to illustrate the horrors of modern warfare",
       "Social Darwinists seeking to illustrate their belief in survival of the fittest",
       "Leftists seeking to show how the working classes were oppressed through military recruitment"
      ],
      "answer": "A"
     },
     {
      "stem": "Otto Dix’s painting is part of the cultural context of",
      "choices": [
       "the dislocation and pessimism of the “lost generation”",
       "Christian churches’ response to totalitarianism",
       "a confidence in technology’s ability to fix society’s problems",
       "a return to traditional modes of artistic expression"
      ],
      "answer": "A"
     }
    ]
   },
   {
    "passage": {
     "intro": "Questions 53–55 refer to the passage below.",
     "items": [
      "“Interrogator: Do you believe that the imperialist states and their agencies are not interested in weakening and undermining the Soviet regime but in strengthening it? Is that how we must interpret you?",
      "Yuri Orlov: As is well known, my documents have been used in the West by those progressive forces whose criticism has clearly improved certain aspects of human rights in the Soviet Union. I have in mind statements by communists in France, Italy, and [other countries]. . . . One must bear in mind that even criticism from hostile forces can be useful for a regime. For example, criticism of capitalism by the Soviet Union has undoubtedly strengthened that system and prolonged its existence. However, I did not appeal to hostile forces [in the West], but either to the international public as a whole, or to left-wingers, including communists. . . . ” supplying documents to Western human rights’ groups, conducted by the KGB,",
      {
       "src": "Interrogation record of Soviet physicist and dissident Yuri Orlov, accused of supplying documents to Western human rights’ groups, conducted by the KGB, December 29, 1977"
      }
     ]
    },
    "questions": [
     {
      "stem": "The interrogator’s reference to “imperialist states” is best understood in the context of which of the following?",
      "choices": [
       "Decolonization following the conclusion of the Second World War",
       "The distribution of German colonies to Britain and France through the mandate system",
       "The emergence of fascist states in Western Europe",
       "Ideological conflicts associated with the Cold War"
      ],
      "answer": "D"
     },
     {
      "stem": "The interrogation recorded in the passage best demonstrates continuity with which of the following?",
      "choices": [
       "Stalin’s program of economic centralization",
       "Lenin’s free-market reforms associated with the New Economic Policy",
       "Khrushchev’s de-Stalinization policies",
       "Stalin’s policies toward political opponents"
      ],
      "answer": "D"
     },
     {
      "stem": "The Soviet regime’s approach to dissent as exemplified in the passage would be most significantly changed as a result of which of the following?",
      "choices": [
       "The increase of diplomatic pressure from the United Nations",
       "The resurgence of ethnic instability in Central and Eastern Europe",
       "The implementation of Gorbachev’s policies of perestroika and glasnost",
       "The period of growth in Western Europe known as the “economic miracle”"
      ],
      "answer": "C"
     }
    ]
   }
  ]
 }
};
window.TESTS.mix = {title:"AP European History Mixed Practice Exam", short:"Mixed Practice Exam", mixFrom:["y2017","ced"], count:55};
